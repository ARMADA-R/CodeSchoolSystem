<?php namespace App\Controllers;
use CodeIgniter\API\ResponseTrait;
use App\Models\TicketsModel;
use App\Models\UserModel;
use App\Models\MessaingModel;
use CodeIgniter\HTTP\RequestInterface;
use App\Controllers\Check;
class Tickets extends BaseController
{ use ResponseTrait;
    public function GetAdminSchoolsTickets(){
      

            if($this->request->getMethod()=='get'){
                $check = new Check(); // Create an instance
                $result=$check->check();
            
                if($result['code']==1){
                    $school_name=$this->request->getVar('school_name');
                    $status=$this->request->getVar('status');
                    $date=$this->request->getVar('date');
                $model=new TicketsModel();
                $result=$model->get_schooladminticket($school_name,$status,$date,1);
                if(!empty($result)){
                $data=array('code'=>1,'msg'=>'success','data'=>$result);
    return	$this->respond($data, 200);
                }
                else{
                    $data=array('code'=>1,'msg'=>'no data found','data'=>[]);
    return	$this->respond($data, 200);
                }
            }
            else{
                $result=array('code'=>$result['code'],'msg'=>$result['messages'],
            );
            return $this->respond($result,400);
            }
            }
    else{
        $data=array('code'=>-1,'msg'=>'Method must be GET','data'=>[]);
    return	$this->respond($data, 200);
    }
}
    
    public function GetAdminSchoolsTicketsBySchoolId(){
      

        if($this->request->getMethod()=='get'){
            $check = new Check(); // Create an instance
            $result=$check->check();
        
            if($result['code']==1){
                $school_id=$this->request->getVar('school_id');
                if(!$school_id){
                    $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل  المدرسة ');
                  return $this->respond($result,400);
                  exit;
                }
            $model=new TicketsModel();
            $result=$model->get_schooladminticketbyschool($school_id,1);
            if(!empty($result)){
            $data=array('code'=>1,'msg'=>'success','data'=>$result);
return	$this->respond($data, 200);
            }
            else{
                $data=array('code'=>1,'msg'=>'no data found','data'=>[]);
return	$this->respond($data, 200);
            }
        }
        else{
            $result=array('code'=>$result['code'],'msg'=>$result['messages'],
        );
        return $this->respond($result,400);
        }
        }
else{
    $data=array('code'=>-1,'msg'=>'Method must be GET','data'=>[]);
return	$this->respond($data, 200);
}


}
public function GetTicketsReply(){
      

    if($this->request->getMethod()=='get'){
        $check = new Check(); // Create an instance
        $result=$check->check();
    
        if($result['code']==1){
            $ticket_id=$this->request->getVar('ticket_id');
            if(!$ticket_id){
                $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل  رقم التذكرة ');
              return $this->respond($result,400);
              exit;
            }
        $model=new TicketsModel();
        $result=$model->get_schooladminticketreply($ticket_id);
        $ticket=$model->get_ticket($ticket_id);
        $tickets=array();
        if(!empty($result)){
            $i=0;
            foreach($result as $item){
$tickets['ticket_text']=$ticket->ticket_text;
$tickets['department']=$ticket->department;
$tickets['type']=$ticket->type;
$tickets['prority']=$ticket->prority;
$tickets['reply'][]=array('reply'=>$item->reply,'username'=>$item->username,'date'=>$item->create_date);
            }
        $data=array('code'=>1,'msg'=>'success','data'=>$tickets);
return	$this->respond($data, 200);
        }
        else{
            $data=array('code'=>1,'msg'=>'no data found','data'=>[]);
return	$this->respond($data, 200);
        }
    }
    else{
        $result=array('code'=>$result['code'],'msg'=>$result['messages'],
    );
    return $this->respond($result,400);
    }
    }
else{
$data=array('code'=>-1,'msg'=>'Method must be GET','data'=>[]);
return	$this->respond($data, 200);
}


}
public function ReplyTicket(){
      

    if($this->request->getMethod()=='post'){
        $check = new Check(); // Create an instance
        $result=$check->check();
    
        if($result['code']==1){
            $ticket_id=$this->request->getVar('ticket_id');
            $user_id=$this->request->getVar('user_id');
            $reply=$this->request->getVar('reply');
            if(!$ticket_id){
                $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل  رقم التذكرة ');
              return $this->respond($result,400);
              exit;
            }
            if(!$user_id){
                $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل   المستخدم ');
              return $this->respond($result,400);
              exit;
            }
            if(!$reply){
                $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل  الرد  ');
              return $this->respond($result,400);
              exit;
            }
        $model=new TicketsModel();
        $data=array('user_id'=>$user_id,'ticket_id'=>$ticket_id,'reply'=>$reply);
        $result=$model->add_reply($data);
      
        if($result==1){
    
        $data=array('code'=>1,'msg'=>'success','data'=>[]);
return	$this->respond($data, 200);
        }
        else{
            $data=array('code'=>1,'msg'=>'no data found','data'=>[]);
return	$this->respond($data, 200);
        }
    }
    else{
        $result=array('code'=>$result['code'],'msg'=>$result['messages'],
    );
    return $this->respond($result,400);
    }
    }
else{
$data=array('code'=>-1,'msg'=>'Method must be POST','data'=>[]);
return	$this->respond($data, 200);
}


}
public function CloseTicket(){
	
	
    if($this->request->getMethod()=='put'){
        $check = new Check(); // Create an instance
        $result=$check->check();
    
        if($result['code']==1){
            $input=$this->request->getRawInput();;
            $id=isset($input['id']) ? $input['id'] :'';
            $status=isset($input['status']) ? $input['status'] :'';
            $user_id=isset($input['user_id']) ? $input['user_id'] :'';
            if(!$id){
                $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل  التعرفة');
              return $this->respond($result,400);
              exit;
            }
            if(strlen($status)==0){
                $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل  الحالة');
              return $this->respond($result,400);
              exit;
            }
            if(strlen($user_id)==0){
                $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل  المستخدم');
              return $this->respond($result,400);
              exit;
            }
            $data=array('status'=>$status,'user_close_ticket'=>$user_id);

        $model=new TicketsModel();
        $update=$model->closeticket($data,$id);
        if($update==1)
        {
            $data=array('code'=>1,'msg'=>'success','data'=>[]);
            return	$this->respond($data, 200);
        }
        else{
            $data=array('code'=>-1,'msg'=>'fail','data'=>[]);
            return	$this->respond($data, 400);
        }
    }
    else{
        $result=array('code'=>$result['code'],'msg'=>$result['messages'],
    );
    return $this->respond($result,400);
    }
    }
else{
$data=array('code'=>-1,'msg'=>'Method must be PUT','data'=>[]);
return	$this->respond($data, 200);
}
    }
    public function GetSchoolsParentsTickets(){
      

            if($this->request->getMethod()=='get'){
                $check = new Check(); // Create an instance
                $result=$check->check();
            
                if($result['code']==1){
                    $school_name=$this->request->getVar('school_name');
                    $status=$this->request->getVar('status');
                    $date=$this->request->getVar('date');
                $model=new TicketsModel();
                $result=$model->get_schooladminticket($school_name,$status,$date,2);
                if(!empty($result)){
                $data=array('code'=>1,'msg'=>'success','data'=>$result);
    return	$this->respond($data, 200);
                }
                else{
                    $data=array('code'=>1,'msg'=>'no data found','data'=>[]);
    return	$this->respond($data, 200);
                }
            }
            else{
                $result=array('code'=>$result['code'],'msg'=>$result['messages'],
            );
            return $this->respond($result,400);
            }
            }
    else{
        $data=array('code'=>-1,'msg'=>'Method must be GET','data'=>[]);
    return	$this->respond($data, 200);
    }
}
public function GetSchoolsParentsTicketsBySchoolId(){
      

    if($this->request->getMethod()=='get'){
        $check = new Check(); // Create an instance
        $result=$check->check();
    
        if($result['code']==1){
            $school_id=$this->request->getVar('school_id');
            if(!$school_id){
                $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل  المدرسة ');
              return $this->respond($result,400);
              exit;
            }
        $model=new TicketsModel();
        $result=$model->get_schooladminticketbyschool($school_id,2);
        if(!empty($result)){
        $data=array('code'=>1,'msg'=>'success','data'=>$result);
return	$this->respond($data, 200);
        }
        else{
            $data=array('code'=>1,'msg'=>'no data found','data'=>[]);
return	$this->respond($data, 200);
        }
    }
    else{
        $result=array('code'=>$result['code'],'msg'=>$result['messages'],
    );
    return $this->respond($result,400);
    }
    }
else{
$data=array('code'=>-1,'msg'=>'Method must be GET','data'=>[]);
return	$this->respond($data, 200);
}


}    
public function GetPartnersAdminTickets(){
      

    if($this->request->getMethod()=='get'){
        $check = new Check(); // Create an instance
        $result=$check->check();
    
        if($result['code']==1){
            $partner_name=$this->request->getVar('partner_name');
            $status=$this->request->getVar('status');
            $date=$this->request->getVar('date');
        $model=new TicketsModel();
        $result=$model->get_schooladminticket($partner_name,$status,$date,3);
        if(!empty($result)){
        $data=array('code'=>1,'msg'=>'success','data'=>$result);
return	$this->respond($data, 200);
        }
        else{
            $data=array('code'=>1,'msg'=>'no data found','data'=>[]);
return	$this->respond($data, 200);
        }
    }
    else{
        $result=array('code'=>$result['code'],'msg'=>$result['messages'],
    );
    return $this->respond($result,400);
    }
    }
else{
$data=array('code'=>-1,'msg'=>'Method must be GET','data'=>[]);
return	$this->respond($data, 200);
}
}
public function GetAdminPartnersTicketsById(){
      

    if($this->request->getMethod()=='get'){
        $check = new Check(); // Create an instance
        $result=$check->check();
    
        if($result['code']==1){
            $partner_id=$this->request->getVar('partner_id');
            if(!$partner_id){
                $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل  الشريك ');
              return $this->respond($result,400);
              exit;
            }
        $model=new TicketsModel();
        $result=$model->get_schooladminticketbyschool($partner_id,3);
        if(!empty($result)){
        $data=array('code'=>1,'msg'=>'success','data'=>$result);
return	$this->respond($data, 200);
        }
        else{
            $data=array('code'=>1,'msg'=>'no data found','data'=>[]);
return	$this->respond($data, 200);
        }
    }
    else{
        $result=array('code'=>$result['code'],'msg'=>$result['messages'],
    );
    return $this->respond($result,400);
    }
    }
else{
$data=array('code'=>-1,'msg'=>'Method must be GET','data'=>[]);
return	$this->respond($data, 200);
}


}    
}