<?php namespace App\Controllers;
use CodeIgniter\API\ResponseTrait;
use App\Models\StudentsModel;
use CodeIgniter\HTTP\RequestInterface;
use App\Controllers\Check;
class Students extends BaseController
{ use ResponseTrait;
    public function GetٍStudents(){
        if($this->request->getMethod()=='get'){
			$check = new Check(); // Create an instance
			$result=$check->check();
		
			if($result['code']==1){
                $school_id=$this->request->getVar('school_id');
                if(!$school_id){
                    $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل المدرسة ');
                  return $this->respond($result,400);
                  exit;
                }
			$model=new StudentsModel();
			$result=$model->get_students($school_id);
			if(!empty($result)){
			$data=array('code'=>1,'msg'=>'success','data'=>$result);
return	$this->respond($data, 200);
			}
			else{
				$data=array('code'=>1,'msg'=>'no data found','data'=>[]);
return	$this->respond($data, 200);
			}
		}
		else{
			$result=array('code'=>$result['code'],'msg'=>$result['messages'],
		);
		return $this->respond($result,400);
		}
		}
else{
	$data=array('code'=>-1,'msg'=>'Method must be GET','data'=>[]);
return	$this->respond($data, 200);
    }
}
public function AddStudent(){

    if($this->request->getMethod()=='post'){
        $check = new Check(); // Create an instance
        $result=$check->check();
    
        if($result['code']==1){
    $full_name=$this->request->getVar('full_name');
    $student_number=$this->request->getVar('student_number');
    $phone=$this->request->getVar('phone');
    $class=$this->request->getVar('class');
    $semestar=$this->request->getVar('semestar');
    $school_id=$this->request->getVar('school_id');
    if(!$school_id){
        $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل المدرسة ');
      return $this->respond($result,400);
      exit;
    }
    if(!$full_name){
        $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل اسم الطالب ');
      return $this->respond($result,400);
      exit;
    }
    if(!$student_number){
        $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل  رقم الطالب ');
      return $this->respond($result,400);
      exit;
    }
    if(!$class){
        $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل  الصف  ');
      return $this->respond($result,400);
      exit;
    }
    if(!$semestar){
        $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل  الفصل  ');
      return $this->respond($result,400);
      exit;
    }

        $model=new StudentsModel();
    $data=array('school_id'=>$school_id,'full_name'=>$full_name,'student_number'=>$student_number,'phone'=>$phone,'class'=>$class,'semestar'=>$semestar);
            if($model->add_student($data)){
                $data=array('code'=>1,'msg'=>'success','data'=>[]);
                return	$this->respond($data, 200);
            }
            else{
                $data=array('code'=>-1,'msg'=>'fail','data'=>[]);
                return	$this->respond($data, 400);
            }
        
    }
    else{
        $result=array('code'=>$result['code'],'msg'=>$result['messages'],
    );
    return $this->respond($result,400);
    }
    }
else{
$data=array('code'=>-1,'msg'=>'Method must be POST','data'=>[]);
return	$this->respond($data, 200);
}
}
public function EditStudent(){
	
	
	if($this->request->getMethod()=='put'){
		$check = new Check(); // Create an instance
		$result=$check->check();
	
		if($result['code']==1){
			$input=$this->request->getRawInput();;
			$full_name=isset($input['full_name']) ? $input['full_name'] :'';
			$id=isset($input['id']) ? $input['id'] :'';
            $student_number=isset($input['student_number']) ? $input['student_number'] :'';
            $phone=isset($input['phone']) ? $input['phone'] :'';
            $class=isset($input['class']) ? $input['class'] :'';
            $semestar=isset($input['semestar']) ? $input['semestar'] :'';
           
			if(!$id){
                $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل التعرفة ');
              return $this->respond($result,400);
              exit;
            }
            if(!$full_name){
                $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل اسم الطالب ');
              return $this->respond($result,400);
              exit;
            }
            if(!$student_number){
                $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل  رقم الطالب ');
              return $this->respond($result,400);
              exit;
            }
            if(!$class){
                $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل  الصف  ');
              return $this->respond($result,400);
              exit;
            }
            if(!$semestar){
                $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل  الفصل  ');
              return $this->respond($result,400);
              exit;
            }
            $data=array('full_name'=>$full_name,'student_number'=>$student_number,'phone'=>$phone,'class'=>$class,'semestar'=>$semestar);

		$model=new StudentsModel();
        $update=$model->edit_student($data,$id);
       
		if($update==1)
		{
			$data=array('code'=>1,'msg'=>'success','data'=>[]);
			return	$this->respond($data, 200);
		}
		else{
			$data=array('code'=>-1,'msg'=>'fail','data'=>[]);
			return	$this->respond($data, 400);
		}
	}
	else{
		$result=array('code'=>$result['code'],'msg'=>$result['messages'],
	);
	return $this->respond($result,400);
	}
	}
else{
$data=array('code'=>-1,'msg'=>'Method must be PUT','data'=>[]);
return	$this->respond($data, 200);
}
    }
    public function GetStudentByID(){

		if($this->request->getMethod()=='get'){
			$check = new Check(); // Create an instance
			$result=$check->check();
		
			if($result['code']==1){
                $id=$this->request->getVar('id');
                if(!$id){
                    $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل التعرفة ');
                  return $this->respond($result,400);
                  exit;
                }
			$model=new StudentsModel();
			$result=$model->get_student_by_id($id);
			if(!empty($result)){
			$data=array('code'=>1,'msg'=>'success','data'=>$result);
return	$this->respond($data, 200);
			}
			else{
				$data=array('code'=>1,'msg'=>'no data found','data'=>[]);
return	$this->respond($data, 200);
			}
		}
		else{
			$result=array('code'=>$result['code'],'msg'=>$result['messages'],
		);
		return $this->respond($result,400);
		}
		}
else{
	$data=array('code'=>-1,'msg'=>'Method must be GET','data'=>[]);
return	$this->respond($data, 200);
}
    }
    public function DeleteStudent(){
		
		if($this->request->getMethod()=='delete'){
			$check = new Check(); // Create an instance
		$result=$check->check();
	
		if($result['code']==1){
		$input=$this->request->getRawInput();;
		$id=isset($input['id']) ? $input['id'] :'';
			if(!$id){
				$data=array('code'=>-1,'msg'=>'Please insert id flied','data'=>[]);
		return	$this->respond($data, 400);
		exit;
			}
			$model=new StudentsModel();
		
			$delete=$model->delete_students($id);
			if($delete==1)
		{
			$data=array('code'=>1,'msg'=>'success','data'=>[]);
			return	$this->respond($data, 200);
		}
		else{
			$data=array('code'=>-1,'msg'=>'fail','data'=>[]);
			return	$this->respond($data, 400);
		}
	}
	else{
		$result=array('code'=>$result['code'],'msg'=>$result['messages'],
	);
	return $this->respond($result,400);
	}
		}
		else{
			$data=array('code'=>-1,'msg'=>'Method must be Delete','data'=>[]);
			return	$this->respond($data, 200);
			}
	}
}