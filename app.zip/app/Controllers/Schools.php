<?php namespace App\Controllers;
use CodeIgniter\API\ResponseTrait;
use App\Models\SchoolModel;
use App\Models\UserModel;
use App\Models\MessaingModel;
use CodeIgniter\HTTP\RequestInterface;
use App\Controllers\Check;
class Schools extends BaseController
{ use ResponseTrait;
    public function GetSchools(){

		if($this->request->getMethod()=='get'){
			$check = new Check(); // Create an instance
			$result=$check->check();
		
			if($result['code']==1){
                $page=$this->request->getVar('page');
                $limit=$this->request->getVar('limit');
                if(strlen($page)!=0){
                    $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل الصفحة ');
                  return $this->respond($result,400);
                  exit;
                }
                if(!$limit){
                    $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل عدد العناصر ');
                  return $this->respond($result,400);
                  exit;
                }
			$model=new SchoolModel();
			$result=$model->get_school($limit,$page);
			if(!empty($result)){
			$data=array('code'=>1,'msg'=>'success','data'=>$result);
return	$this->respond($data, 200);
			}
			else{
				$data=array('code'=>1,'msg'=>'no data found','data'=>[]);
return	$this->respond($data, 200);
			}
		}
		else{
			$result=array('code'=>$result['code'],'msg'=>$result['messages'],
		);
		return $this->respond($result,400);
		}
		}
else{
	$data=array('code'=>-1,'msg'=>'Method must be GET','data'=>[]);
return	$this->respond($data, 200);
}

}
public function GetServicesSchools(){

    if($this->request->getMethod()=='get'){
        $check = new Check(); // Create an instance
        $result=$check->check();
    
        if($result['code']==1){
       
        $model=new SchoolModel();
        $result=$model->get_services();
        if(!empty($result)){
        $data=array('code'=>1,'msg'=>'success','data'=>$result);
return	$this->respond($data, 200);
        }
        else{
            $data=array('code'=>1,'msg'=>'no data found','data'=>[]);
return	$this->respond($data, 200);
        }
    }
    else{
        $result=array('code'=>$result['code'],'msg'=>$result['messages'],
    );
    return $this->respond($result,400);
    }
    }
else{
$data=array('code'=>-1,'msg'=>'Method must be GET','data'=>[]);
return	$this->respond($data, 200);
}

}
public function EditSchool(){
	
	
	if($this->request->getMethod()=='post'){
		$check = new Check(); // Create an instance
		$result=$check->check();
	
		if($result['code']==1){
		       $school_name=$this->request->getVar('school_name');
		        $id=$this->request->getVar('id');
            $edcution_type=$this->request->getVar('edcution_type');
            $school_number=$this->request->getVar('school_number');
            $city=$this->request->getVar('city');
            $area=$this->request->getVar('area');
            $email=$this->request->getVar('email');
            $password=$this->request->getVar('password');
            $status=$this->request->getVar('status');
            $phone=$this->request->getVar('phone');
             $category=$this->request->getVar('category');
               $username=$this->request->getVar('username');
		
    
            if(!$email){
                $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل الايميل ');
              return $this->respond($result,400);
              exit;
            }
            if(!$password){
                $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل كلمة المرور ');
              return $this->respond($result,400);
              exit;
			}
			if(!$id){
                $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل التعرفة ');
              return $this->respond($result,400);
              exit;
            }
            $usermodel=new UserModel();
            $model=new SchoolModel();
            // $check_email=$usermodel->get_user_email($email);
            // if(empty($check_email)){
                $data = [
         
                    'email'=>$email,
                    'password'=>md5($password),
                    'city'=>$city,
                    'area'=>$area,
                    'phone'=>$phone,
                    'username'=>$username,
                    'status'=>1
                  
                    ];
        
                if($model->edit_school($data,$id)){
                    $data2 = [
                        'school_name'=>$school_name,
                        'education_type'=>$edcution_type,
                        'school_number'=>$school_number,
                        'category'=>$category
                      
                        ];
                    
                       
                        $info=$model->edit_info($data2,$id);
                      
                        $data=array('code'=>1,'msg'=>'success','data'=>[]);
                        return	$this->respond($data, 200);
            // }
            // else{
            //     $data=array('code'=>-1,'msg'=>'fail','data'=>[]);
            //     return	$this->respond($data, 400);
            // }

            
        }
			
        else{
            $data=array('code'=>-1,'msg'=>'fail','data'=>[]);
                return	$this->respond($data, 400);
            exit;
        }
	
	}
	else{
		$result=array('code'=>$result['code'],'msg'=>$result['messages'],
	);
	return $this->respond($result,400);
	}
	}
else{
$data=array('code'=>-1,'msg'=>'Method must be POST','data'=>[]);
return	$this->respond($data, 200);
}
    }
    public function EditServiceSchool(){
	
	
        if($this->request->getMethod()=='put'){
            $check = new Check(); // Create an instance
            $result=$check->check();
        
            if($result['code']==1){
                $input=$this->request->getRawInput();;
               
                $service_id=isset($input['service_id']) ? $input['service_id'] :'';
               
                $school_id=isset($input['school_id']) ? $input['school_id'] :'';
                $end_date=isset($input['end_date']) ? $input['end_date'] :'';
                $status=isset($input['status']) ? $input['status'] :'';
                if(!$service_id){
                    $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل الخدمة ');
                  return $this->respond($result,400);
                  exit;
                }
                if(!$school_id){
                    $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل  المدرسة ');
                  return $this->respond($result,400);
                  exit;
                }
                if(!$end_date){
                    $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل التاريخ ');
                  return $this->respond($result,400);
                  exit;
                }
                if(strlen($status)==0){
                    $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل  الحالة');
                  return $this->respond($result,400);
                  exit;
                }
                $model=new SchoolModel();
                $check_service=$model->get_service_by_id($service_id,$school_id);
                if(!empty($check_service)){
                    $data=array('service_id'=>$service_id,'school_id'=>$school_id,'end_date'=>$end_date,'status'=>$status);
                    $update=$model->edit_service($data);
                    if($update==1)
                    {
                        $data=array('code'=>1,'msg'=>'success','data'=>[]);
                        return	$this->respond($data, 200);
                    }
                    else{
                        $data=array('code'=>-1,'msg'=>'fail','data'=>[]);
                        return	$this->respond($data, 400);
                    }
                }
                else{
                    $data=array('service_id'=>$service_id,'school_id'=>$school_id,'end_date'=>$end_date,'status'=>$status);
                    $update=$model->add_service($data);
                    if($update==1)
                    {
                        $data=array('code'=>1,'msg'=>'success','data'=>[]);
                        return	$this->respond($data, 200);
                    }
                    else{
                        $data=array('code'=>-1,'msg'=>'fail','data'=>[]);
                        return	$this->respond($data, 400);
                    }
                }
                
        }
        else{
            $result=array('code'=>$result['code'],'msg'=>$result['messages'],
        );
        return $this->respond($result,400);
        }
        }
    else{
    $data=array('code'=>-1,'msg'=>'Method must be PUT','data'=>[]);
    return	$this->respond($data, 200);
    }
        }
        public function UpdateSchoolStatus(){
	
	
            if($this->request->getMethod()=='put'){
                $check = new Check(); // Create an instance
                $result=$check->check();
            
                if($result['code']==1){
                    $input=$this->request->getRawInput();;
                    $id=isset($input['id']) ? $input['id'] :'';
                    $status=isset($input['status']) ? $input['status'] :'';
                    if(!$id){
                        $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل  التعرفة');
                      return $this->respond($result,400);
                      exit;
                    }
                    if(strlen($status)==0){
                        $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل  الحالة');
                      return $this->respond($result,400);
                      exit;
                    }
            
                    $data=array('status'=>$status);
        
                $model=new SchoolModel();
                $update=$model->edit_school($data,$id);
                if($update==1)
                {
                    $data=array('code'=>1,'msg'=>'success','data'=>[]);
                    return	$this->respond($data, 200);
                }
                else{
                    $data=array('code'=>-1,'msg'=>'fail','data'=>[]);
                    return	$this->respond($data, 400);
                }
            }
            else{
                $result=array('code'=>$result['code'],'msg'=>$result['messages'],
            );
            return $this->respond($result,400);
            }
            }
        else{
        $data=array('code'=>-1,'msg'=>'Method must be PUT','data'=>[]);
        return	$this->respond($data, 200);
        }
            }
            public function SendAdminEmailtoSchool(){
                if( $this->request->getMethod() =='post'){
                    $admin_email=$this->request->getVar('admin_email');
                    $school_email=$this->request->getVar('school_email');
                    $message_title=$this->request->getVar('message_title');
                    $message_text=$this->request->getVar('message_text');
                    if(!$admin_email){
                        $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل ايميل المدير ');
                      return $this->respond($result,400);
                      exit;
                    }
                    if(!$school_email){
                        $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل ايميل المدرسة ');
                      return $this->respond($result,400);
                      exit;
                    }
                    if(!$message_title){
                        $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل عنوان الرسالة  ');
                      return $this->respond($result,400);
                      exit;
                    }
                    if(!$message_text){
                        $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل نص الرسالة  ');
                      return $this->respond($result,400);
                      exit;
                    }
                    $model=new UserModel();
                    $check_email=$model->get_user_email($school_email);
                   
                    if(!empty($check_email)){
                  
                    $subject = 'تغير كلمة المرور';

                    $headers = "From: ".$admin_email."\r\n";
                    $headers .= "Reply-To: ". $school_email . "\r\n";
                    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                    
                    $message = '<p><strong>'.$message_title."</strong> \r\n<p>".$message_text."</p>";
                    
                    
                    // if(mail($to, $subject, $message, $headers)){
                    //     $result=array('code'=>1,'msg'=>'success',
                    // );
                    // return $this->respond($result,200);
                    // }
                    // else{
                    //     $result=array('code'=>-1,'msg'=>'fail',
                    // );
                    // return $this->respond($result,200);
                    // }
                    // $data=['sender_id'=>$sender_id,'reciver_id'=>$reciver_id,'message'=>$message_text,'title'=>$message_title,'sender_type'=>1];
                    // $result=$model->add_email($data);
                    // if($result){
                    //     $result=array('code'=>1,'msg'=>'success'
                    // );
            
                    // return $this->respond($result,200);
                    // }
                    // else{
                    //     $result=array('code'=>-1,'msg'=>'fail'
                    // );
            
                    // return $this->respond($result,400);
                    // }
                }
                else{
                    $result=array('code'=>-1,'msg'=>'الايميل غير موجود'
                );
        
                return $this->respond($result,400);
                }
                }
                else{
                    $result=array('code'=>-1,'msg'=>'Method must be POST',
                    );
                    return $this->respond($result,400);
                }}

                public function GetSchoolByID(){

                    if($this->request->getMethod()=='get'){
                        $check = new Check(); // Create an instance
                        $result=$check->check();
                    
                        if($result['code']==1){
                            $id=$this->request->getVar('id');
                            if(!$id){
                                $result=array('code'=>-1,'msg'=>'الرجاء إدخال حقل التعرفة ');
                              return $this->respond($result,400);
                              exit;
                            }
                        $model=new SchoolModel();
                        $result=$model->get_school_by_id($id);
                        if(!empty($result)){
                        $data=array('code'=>1,'msg'=>'success','data'=>$result);
            return	$this->respond($data, 200);
                        }
                        else{
                            $data=array('code'=>1,'msg'=>'no data found','data'=>[]);
            return	$this->respond($data, 200);
                        }
                    }
                    else{
                        $result=array('code'=>$result['code'],'msg'=>$result['messages'],
                    );
                    return $this->respond($result,400);
                    }
                    }
            else{
                $data=array('code'=>-1,'msg'=>'Method must be GET','data'=>[]);
            return	$this->respond($data, 200);
            }
                }
                public function DeleteSchool(){
		
                    if($this->request->getMethod()=='delete'){
                        $check = new Check(); // Create an instance
                    $result=$check->check();
                
                    if($result['code']==1){
                    $input=$this->request->getRawInput();;
                    $id=isset($input['id']) ? $input['id'] :'';
                        if(!$id){
                            $data=array('code'=>-1,'msg'=>'Please insert id flied','data'=>[]);
                    return	$this->respond($data, 400);
                    exit;
                        }
                        $model=new EmployeeModel();
                    
                        $delete=$model->delete_employee($id);
                        if($delete==1)
                    {
                        $data=array('code'=>1,'msg'=>'success','data'=>[]);
                        return	$this->respond($data, 200);
                    }
                    else{
                        $data=array('code'=>-1,'msg'=>'fail','data'=>[]);
                        return	$this->respond($data, 400);
                    }
                }
                else{
                    $result=array('code'=>$result['code'],'msg'=>$result['messages'],
                );
                return $this->respond($result,400);
                }
                    }
                    else{
                        $data=array('code'=>-1,'msg'=>'Method must be Delete','data'=>[]);
                        return	$this->respond($data, 200);
                        }
                }
}