<?php namespace App\Models;

use CodeIgniter\Model;
use CodeIgniter\Database\BaseBuilder;
class TicketsModel extends Model
{
  
    public function get_schooladminticket($name=null,$status=null,$date=null,$sender_type){

          
            $db = \Config\Database::connect();
            $builder = $db->table('tickets');
            $builder->select('users.username,category,users.email,users.phone,users.city,users.area');
            $builder->join('users', 'tickets.sender_id = users.id');
            $builder->join('users s', 'tickets.reciver_id = s.id');
            $builder->join('school_info', 'users.id = school_info.school_id','');
           if(!empty($name)){
            $builder->like('school_name',$name);
           }
           if(strlen($status)!=0){
            $builder->where('tickets.status',$status);
           }
           if(!empty($date)){
                $search_where = "CAST(tickets.create_date As Date) = '".$date."'";
            $builder->where($search_where);
           }
            $builder->where('sender_type', $sender_type);
      
            $query   = $builder->get();
           
            return $query->getResult();
        
    }
    public function get_schooladminticketbyschool($school_id,$sender_type){

          
        $db = \Config\Database::connect();
//         $builder = $db->table('tickets');
//         $builder->select('ticket_text,department,type,prority,reply,max(tickets_reply.id)');
//         $builder->join('tickets_reply', 'tickets.id = tickets_reply.ticket_id','left');
       
//         $builder->where('tickets.sender_id',$school_id);
//         $builder->where('sender_type', 1);
//        $builder->orderBy('tickets_reply.create_date','desc');
//        $query =$db->query('select tickets.id,tickets.status,users.username,department,type,prority,ticket_text,reply FROM tickets left join tickets_reply on tickets.id=tickets_reply.ticket_id left join users on tickets_reply.user_id=users.id where sender_id='.$school_id .' and sender_type='.$sender_type. ' and tickets_reply.id in (select max(id) from tickets_reply group by ticket_id) ');
        // $query   = $builder->get();
       $query=$db->query('Select users.username,a.id, b.* From tickets a left Join( Select *, ROW_NUMBER() OVER(PARTITION BY ticket_id ORDER BY create_date DESC) AS num_row  From tickets_reply) b On b.ticket_id = a.id left Join  users on b.user_id=users.id  where   (sender_id='.$school_id .' and sender_type='.$sender_type.') and (num_row is NULL or num_row=1)');
        return $query->getResult();
    
}
public function get_schooladminticketreply($ticket_id){

          
        $db = \Config\Database::connect();
        $builder = $db->table('tickets_reply');
        $builder->select('reply,username,tickets_reply.create_date');
        $builder->join('users', 'tickets_reply.user_id = users.id');
       
        $builder->where('tickets_reply.ticket_id',$ticket_id);
       
       $builder->orderBy('tickets_reply.create_date','desc');
    
        $query   = $builder->get();
       
        return $query->getResult();
    
}
public function get_ticket($ticket_id){

          
        $db = \Config\Database::connect();
        $builder = $db->table('tickets');
        $builder->select('ticket_text,department,type,prority');
        
       
        $builder->where('id',$ticket_id);
       
     
    
        $query   = $builder->get();
       
        return $query->getRow();
    
}
public function add_reply($data){

          
        $db = \Config\Database::connect();
        $builder = $db->table('tickets_reply');
        $builder->insert($data);
        return $db->affectedRows();
      
    
}
public function closeticket($data,$id){

          
        $db = \Config\Database::connect();
        $builder = $db->table('tickets');
        $builder->where('id',$id);
        $builder->update($data);
        return $db->affectedRows();
      
    
}
}