<?php namespace App\Models;

use CodeIgniter\Model;

class TemplateModel extends Model
{
  
    public function get_template(){
        $db = \Config\Database::connect();
        $builder = $db->table('template');
        $builder->select('id, name, content, letters_number,message_number');
        $query   = $builder->get();  
        return $query->getResult();
    }
  
    public function add_template($data){
        $db = \Config\Database::connect();
        $builder = $db->table('template');
        return $builder->insert($data);
       
    }
    public function edit_template($data,$id){
        $db = \Config\Database::connect();
        $builder = $db->table('template');
        $builder->where('id',$id);
        $builder->update($data);
       return $db->affectedRows();
    }
    public function get_template_by_id($id){
        $db = \Config\Database::connect();
        $builder = $db->table('template');
        $builder->select('id, name, content, letters_number,message_number');
        $builder->where('id',$id);
        $query   = $builder->get();  
        return $query->getRow();
       
    }
    public function delete_template($id){
        $db = \Config\Database::connect();
        $builder = $db->table('template');
        $builder->where('id',$id);
         $builder->delete();
         return $db->affectedRows();
       
    }
}