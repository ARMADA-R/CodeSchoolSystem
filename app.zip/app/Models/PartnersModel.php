<?php
namespace App\Models;
use CodeIgniter\Database\ConnectionInterface;
use CodeIgniter\Model;
class PartnersModel extends Model
{
  
   
    public function get_partners($limit,$page){
        $db = \Config\Database::connect();
        
        $date=date('Y-m-d');
        $page=$page*$limit;
        $builder = $db->table('users');
        $builder->distinct();
        $builder->select('username,partner_service.id,service_name,image_url,service_price,service_after_discount,discount,cubon,end_date');
        $builder->join('partner_service', 'users.id = partner_service.user_id');
        $builder->where('role', 4);
        $builder->where('end_date>=', $date);
        
        $builder->orderBy('partner_service.create_date', 'desc');
        $query   = $builder->get($limit,$page);  
        return $query->getResult();
    }
    public function get_service($user_id,$limit,$page){
        $db = \Config\Database::connect();
        $date=date('Y-m-d');
        $page=$page*$limit;
        $builder = $db->table('users');
        $builder->distinct();
        $builder->select('username,partner_service.user_id,service_name,image_url,service_price,service_after_discount,discount,cubon,end_date');
        $builder->join('partner_service', 'users.id = partner_service.user_id');
        $builder->where('role', 4);
        $builder->where('end_date>=', $date);
        $builder->where('user_id', $user_id);
        $builder->orderBy('partner_service.create_date', 'desc');
        $query   = $builder->get($limit,$page);  
        return $query->getResult();
    }
    public function edit_service($data,$id){
        $db = \Config\Database::connect();
        $builder = $db->table('partner_service');
        $builder->where('id',$id);
        $builder->update($data);
       return $db->affectedRows();
    }
}