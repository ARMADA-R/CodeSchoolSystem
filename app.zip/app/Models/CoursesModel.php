<?php namespace App\Models;

use CodeIgniter\Model;

class CoursesModel extends Model
{
  
    public function get_courses($school_id){
        $db = \Config\Database::connect();
        $builder = $db->table('courses');
        $builder->select('courses.id, level, division, full_name');
        $builder->join('students','courses.user_id=students.id');
        $builder->where('courses.school_id',$school_id);
        $query   = $builder->get();  
        return $query->getResult();
    }
  
    public function add_course($data){
        $db = \Config\Database::connect();
        $builder = $db->table('courses');
        return $builder->insert($data);
       
    }
    public function edit_course($data,$id){
        $db = \Config\Database::connect();
        $builder = $db->table('courses');
        $builder->where('id',$id);
        $builder->update($data);
       return $db->affectedRows();
    }
    public function get_course_by_id($id){
        $db = \Config\Database::connect();
        $builder = $db->table('courses');
        $builder->select('courses.id, level, division, user_id');
        $builder->where('id',$id);
        $query   = $builder->get();  
        return $query->getRow();
       
    }
    public function delete_course($id){
        $db = \Config\Database::connect();
        $builder = $db->table('courses');
        $builder->where('id',$id);
         $builder->delete();
         return $db->affectedRows();
       
    }
}