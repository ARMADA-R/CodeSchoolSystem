<?php namespace App\Models;

use CodeIgniter\Model;

class StudentsModel extends Model
{
  
    public function get_students($school_id){
        $db = \Config\Database::connect();
        $builder = $db->table('students');
        $builder->select('id, full_name, student_number, phone, class, semestar');
        $builder->where('school_id',$school_id);
        $query   = $builder->get();  
        return $query->getResult();
    }
  
    public function add_student($data){
        $db = \Config\Database::connect();
        $builder = $db->table('students');
        return $builder->insert($data);
       
    }
    public function edit_student($data,$id){
        $db = \Config\Database::connect();
        $builder = $db->table('students');
        $builder->where('id',$id);
        $builder->update($data);
       return $db->affectedRows();
    }
    public function get_student_by_id($id){
        $db = \Config\Database::connect();
        $builder = $db->table('students');
        $builder->select('id, full_name, student_number, phone, class, semestar');
        $builder->where('id',$id);
        $query   = $builder->get();  
        return $query->getRow();
       
    }
    public function delete_students($id){
        $db = \Config\Database::connect();
        $builder = $db->table('students');
        $builder->where('id',$id);
         $builder->delete();
         return $db->affectedRows();
       
    }
}