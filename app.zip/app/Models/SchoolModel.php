<?php
namespace App\Models;
use CodeIgniter\Database\ConnectionInterface;
use CodeIgniter\Model;
class SchoolModel extends Model
{
  
    public function add_school_info($data){
        $db      = \Config\Database::connect();
        $builder = $db->table('school_info');
       return  $builder->insert($data);
    }
    public function get_school($limit,$page){
        $page=$page*$limit;
        $db = \Config\Database::connect();
        $builder = $db->table('users');
        $builder->select('users.id,education_type,category,school_number,username,email,city,phone,school_name');
        $builder->join('school_info', 'users.id = school_info.school_id');
        $builder->where('role', 2);
        $query   = $builder->get($limit, $page);
        return $query->getResult();
    }
    public function edit_school($data,$id){
        $db = \Config\Database::connect();
        $builder = $db->table('users');
        $builder->where('id',$id);
      return  $builder->update($data);
    
    }
    public function edit_info($data,$id){
        $db = \Config\Database::connect();
        $builder = $db->table('school_info');
        $builder->where('school_id',$id);
      return  $builder->update($data);
    
    }
    public function edit_service($data){
        $db = \Config\Database::connect();
        $builder = $db->table('sevices_schools');
        $builder->where('school_id',$data['school_id']);
        $builder->where('service_id',$data['service_id']);
       return $builder->update($data);
       return $db->affectedRows();
    }
    public function add_service($data){
        $db = \Config\Database::connect();
        $builder = $db->table('sevices_schools');
       
        $builder->insert($data);
        return $db->affectedRows();
    }
    
    public function get_service_by_id($service_id,$school_id){
        $db = \Config\Database::connect();
        $builder = $db->table('sevices_schools');
        $builder->select('id');
        $builder->where('service_id',$service_id);
        $builder->where('school_id',$school_id);
        $query   = $builder->get();  
        return $query->getRow();
       
    }
    public function get_services(){
        $db = \Config\Database::connect();
        $builder = $db->table('service_school');
        $builder->select('id,name');
       
        $query   = $builder->get();  
        return $query->getResult();
       
    }
    public function get_school_by_id($id){
        $db = \Config\Database::connect();
        $builder = $db->table('users');
        $builder->select('users.id,education_type,category,school_number,username,email,city,phone,school_name');
        $builder->join('school_info', 'users.id = school_info.school_id');
        $builder->where('role', 2);
        $query   = $builder->get();
        return $query->getRow();
       
    }
    public function delete_school($id){
        $db = \Config\Database::connect();
        $builder = $db->table('users');
        $builder->where('id',$id);
         $builder->delete();
         return $db->affectedRows();
       
    }
}